import React from 'react';

import SemProjectSlider from '../components/SemProjectSlider';

const Semproject = () => {
  return (
    <div className="">
      <SemProjectSlider sem="3" />
    </div>
  );
};

export default Semproject;
